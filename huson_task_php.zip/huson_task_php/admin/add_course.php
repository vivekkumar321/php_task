<?php 
	require_once('include/check_session.php');	
	include_once('include/header.php');

	$msg='';
	if(isset($_POST['course_add']))
	{
		 $userName=mysqli_real_escape_string($conn,$_POST['userName']);
		 $email=mysqli_real_escape_string($conn,$_POST['email']);
		 $phone=mysqli_real_escape_string($conn,$_POST['phone']);
		 $gender=mysqli_real_escape_string($conn,$_POST['gender']);
		 $course=mysqli_real_escape_string($conn,$_POST['course']);
		 date_default_timezone_set('Asia/Calcutta'); 
		 $added_on = date("Y-m-d H:i:s"); // time in India

		 $sql=mysqli_query($conn, "select * from tbl_course where email='$email'");
		 $checkEmail=mysqli_num_rows($sql);
		 if($checkEmail > 0)
		 {

			$msg="Email Already Exits";
		}
		else
		{
			if(isset($_FILES['photo']['name']) && $_FILES['photo']['name']!='')
			{
				$fileName=$_FILES['photo']['name'];
				$tmp_name=$_FILES['photo']['tmp_name'];
				$FileLocation="../uploadImage/".$fileName;
				move_uploaded_file($tmp_name, $FileLocation);

				$sql = "insert into tbl_course (userName,email,phone,gender,course,image,added_on) VALUES 
				('".$userName."','".$email."','".$phone."','".$gender."','".$course."','$fileName','".$added_on."')";
			}
			else
			{
				$sql = "insert into tbl_course (userName,email,phone,gender,course,added_on) VALUES 
				('".$userName."','".$email."','".$phone."','".$gender."','".$course."','".$added_on."')";
			}
			if($conn->query($sql)){
				echo "<script>alert('Data Added Success')</script>";
				echo "<meta http-equiv='refresh' content='0;url=course.php'/>";
			}else{
				echo "<script>alert('Failed ! please try Again')</script>";
			}
		}
	}
?>
<body>
   <?php include_once('include/leftpannel.php');?>

   <div class="content">
      <div class="animated fadeIn">
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-header"><strong>ADD USER</div>
                  <div class="card-body card-block">
                     <form method="post" enctype="multipart/form-data">

                         <div class="form-group">
                           <label>User Name</label>
                           <input type="text" class="form-control" placeholder="Enter User  Name" 
                           name="userName" value="" required="">
                        </div>
                         <div class="form-group">
                           <label>Email</label>
                           <input type="email" class="form-control" placeholder="Enter Email" 
                           name="email"  value="" required="">
                           <span style="color: red;"><?php echo $msg;?></span>
                        </div>
                        <div class="form-group">
                           <label>Phone</label>
                           <input type="text" class="form-control" placeholder="Enter Phone" 
                           name="phone"  value="" required="">
                        </div>
                          <div class="form-group">
                           <label>Gender</label>
                           <input type="radio"   name="gender"  value="male">Male
                           <input type="radio"   name="gender"  value="female">Female
                        </div>
                      <div class="form-group">
                           <label>Course</label>
                           <select class="form-control" name="course" required="">
                           	<option>Choose Course</option>
                           	<option value="B-tech">B-tech</option>
                           	<option value="M-tech">M-tech</option>
                           	<option value="Mca">Mca</option>
                           	<option value="Bca">Bca</option>
                           </select>
                        </div>
                          <div class="form-group">
                           <label>Image</label>
                           <input type="file" class="form-control"  name="photo">
                        </div>
						
						 
                  <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" name="course_add">Submit</button> 
                  <a href="course.php" class="btn btn-danger btn-flat m-b-30 m-t-30">Back</a>
				  </div>         
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
   </div>
   <!-- .animated -->
   </div>
   <!-- .content -->
   <?php include_once('include/footer.php');?>