<?php 
  error_reporting(0);
  require_once('include/check_session.php');
  include_once('include/header.php');
  
  // delete product 
  if(isset($_GET['del_id']))
  {
   $del_id=mysqli_real_escape_string($conn, $_GET['del_id']);
     $imgSql=mysqli_query($conn ,"SELECT * from tbl_course where id='$del_id'");
     $imgqry=mysqli_fetch_array($imgSql);
     unlink('../uploadImage/'.$imgqry['image']);
     $sql=mysqli_query($conn, "delete from tbl_course where id='$del_id'");
     echo "<meta http-equiv='refresh' content='0;url=course.php'/>";
  }
  
  // pagination code
  $perPage=5;
  // default page first
  $page=1;
  
  if(isset($_GET['page'])){
     $page=mysqli_real_escape_string($conn,$_GET['page']);
  }
  $startFrom=($page-1)*$perPage;
  $sql=mysqli_query($conn, "select * from tbl_course");
  $total=mysqli_num_rows($sql);
  $totalPage=ceil($total/$perPage);
  ?>
<body>
  <!-- Left Panel -->
  <?php include_once('include/leftpannel.php');?>
  <div class="content">
    <div class="animated fadeIn">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <strong class="card-title">USERS LIST</strong>
            </div>
            <a href="add_course.php" class="btn btn-primary btn-lg">ADD USER</a><br/>
            <div class="table-stats order-table ov-h">
              <table class="table ">
                <thead>
                  <tr>
                    <th class="serial">#</th>
                    <th>User Name</th>
                    <th>Phone</th>
                    <th>Course</th>
                    <th>Image</th>
                    <th>Added_on</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                    // get cusrse list
                     $cusrseSql=mysqli_query($conn, "select * from tbl_course order by id ASC limit $startFrom,$perPage");
                     while($row=mysqli_fetch_array($cusrseSql)){?>
                  <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['userName'];?></td>
                    <td><?php echo $row['phone'];?></td>
                    <td><?php echo $row['course'];?></td>
                    <td><img src="../uploadImage/<?php echo $row['image'];?>"></td>
                    <td><?php echo $row['added_on'];?></td>
                    <td><a href="edit_course.php?eid=<?php echo $row['id'];?>" class="btn 
                      btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                      <a href="course.php?del_id=<?php echo $row['id'];?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure want to delete')"><i class="fa fa-trash-o"></i></a>
                    </td>
                  </tr>
                  <?php }?>
                </tbody>
              </table>
              <div class="pagination">
                <?php 
                  for($i=1;$i<=$totalPage;$i++){?>
                <a id="alin" href="?page=<?php echo $i;?>"><?php echo $i;?></a>
                <?php } ?>
              </div>
            </div>
            <!-- /.table-stats -->
          </div>
        </div>
      </div>
    </div>
    <!-- .animated -->
  </div>
  <!-- .content -->
  <?php include_once('include/footer.php');?>