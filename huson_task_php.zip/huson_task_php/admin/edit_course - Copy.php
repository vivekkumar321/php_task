<?php 
  require_once('include/check_session.php');  
  include_once('include/header.php');
  
  // start code for get record on form
  $maleChecked='';
  $femaleChecked='';
  $courseArr=array();
  if(isset($_GET['eid']))
  {
    $eid=mysqli_real_escape_string($conn, $_GET['eid']);
    $sql=mysqli_query($conn, "select * from tbl_course where id='$eid'");
    if(mysqli_num_rows($sql)>0){
      $rowData=mysqli_fetch_assoc($sql);
      if($rowData['gender']=='male'){
        $maleChecked="checked='checked'";
      }
      if($rowData['gender']=='female'){
        $femaleChecked="checked='checked'";
      }
    }else{
      header('location:course.php');
    }
  }
  // Upate Record code 
  
  $msg='';
  
  if(isset($_POST['course_add']))
  {
     $userName=$_POST['userName'];
     $email=$_POST['email'];
     $phone=$_POST['phone'];
     $gender=$_POST['gender'];
     $course=$_POST['course'];
     date_default_timezone_set('Asia/Calcutta'); 
     $added_on = date("Y-m-d H:i:s"); // time in India
     // check email exit validation
     $sql=mysqli_query($conn, "select * from tbl_course where email='$email'");
     $checkEmail=mysqli_num_rows($sql);
     $row=mysqli_fetch_assoc($sql);
     if( $checkEmail > 0)
     {
      if(isset($_GET['eid']))
      {
        if($row['id']==$eid)
        {
  
        }
        else
        {
          $msg="Email Already Exits";
        }
      }
      else
       {
          $msg="Email Already Exits";
       }
  }
  // end check email exit validation
  
  if($msg==''){
    if(isset($_FILES['photo']['name']) && $_FILES['photo']['name']!='')
      {
        $fileName=$_FILES['photo']['name'];
        $tmp_name=$_FILES['photo']['tmp_name'];
        $FileLocation="../uploadImage/".$fileName;
        move_uploaded_file($tmp_name, $FileLocation);
  
        $sql ="UPDATE `tbl_course` SET `userName`='".$userName."',`email`='".$email."',`phone`='".$phone."',`gender`='".$gender."',`course`='".$course."',`image`='$fileName',`added_on`='".$added_on."' WHERE id='".$_POST['id']."'";
      }
      else
      {
        $sql ="UPDATE `tbl_course` SET `userName`='".$userName."',`email`='".$email."',`phone`='".$phone."',`gender`='".$gender."',`course`='".$course."',`added_on`='".$added_on."' WHERE id='".$_POST['id']."'";
      }
      if($conn->query($sql)){
       // echo "<script>alert('Data Update Success')</script>";
       // echo "<meta http-equiv='refresh' content='0;url=course.php'/>";
      }else{
        echo "<script>alert('Failed ! please try Again')</script>";
      }
    }
  }
  ?>
<body>
  <?php include_once('include/leftpannel.php');?>
  <div class="content">
    <div class="animated fadeIn">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><strong>update course</div>
            <div class="card-body card-block">
              <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label>User Name</label>
                  <input type="text" class="form-control" placeholder="Enter User  Name" 
                    name="userName" value="<?php echo $rowData['userName'];?>" required="">
                  <input type="hidden" name="id" value="<?php echo $rowData['id'];?>">
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" class="form-control" placeholder="Enter Email" 
                    name="email"  value="<?php echo $rowData['email'];?>" required="">
                  <span style="color: red;"><?php echo $msg;?></span>
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="text" class="form-control" placeholder="Enter Phone" 
                    name="phone"  value="<?php echo $rowData['phone'];?>" required="">
                </div>
                <div class="form-group">
                  <label>Gender</label>
                  <input type="radio"   name="gender"  value="male"<?php echo $maleChecked;?>>Male
                  <input type="radio"   name="gender"  value="female" <?php echo $femaleChecked;?>>Female
                </div>
                <div class="form-group">
                  <label>Course</label>
                   <div class="form-group">
                         <label>Course</label>
                         <select class="form-control" name="course" required="">
                            <option>Choose Course</option>
                            <option value="B-tech"<?php if($rowData['course']=='B-tech'){?> selected="selected" <?php }?>>B-tech</option>
                            <option value="M-tech"<?php if($rowData['course']=='M-tech'){?> selected="selected" <?php }?>>M-tech</option>
                            <option value="Mca"<?php if($rowData['course']=='Mca'){?> selected="selected" <?php }?>>Mca</option>
                            <option value="Bca"<?php if($rowData['course']=='Bca'){?> selected="selected" <?php }?>>Bca</option>
                         </select>
                  <!-- <?php $courseArr//=//array('B-tech','M-tech','Mca','Bca');?> -->

                 <!--  <select class="form-control" name="course" required="">
                    <option>Choose Course</option>
                    <?php
                    //  foreach ($courseArr as $list) {
                      //  if($rowData['course']==$list){?>
                    <option value="<?php //echo $list; ?>" selected><?php// echo $list; ?></option>
                    }else{?>
                    <option value="<?php// echo $list; ?>"><?php //echo $list; ?></option>
                    <?php } }  ?>
                  </select> -->



                </div>
                <div class="form-group">
                  <label>Image</label>
                  <input type="file" class="form-control"  name="photo">
                </div>
                <div class="form-group">
                  <img src="../uploadImage/<?php echo $rowData['image'];?>" width="200" height="100">
                </div>
                <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" name="course_add">Submit</button> 
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <!-- .animated -->
  </div>
  <!-- .content -->
  <?php include_once('include/footer.php');?>