<?php 
require_once('include/db_connect.php');
if(!isset($_SESSION['USER-ID']))
{
	header('location:index.php');
}

 ?>