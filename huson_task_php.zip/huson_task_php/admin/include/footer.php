<div class="clearfix"></div>
                  <footer class="site-footer">
                     <div class="footer-inner bg-white">
                        <div class="row">
                           <div class="col-sm-6">
                              Copyright &copy; <?php echo date('Y');?> 
                           </div>
                           <div class="col-sm-6 text-right">
                              Designed by <a href="#">Colorlib</a>
                           </div>
                        </div>
                     </div>
                  </footer>
               </div>
               <!-- /#right-panel -->
               <!-- Right Panel -->
               <!-- Scripts -->
               <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
               <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
               <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
               <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
               <script src="assets/js/main.js"></script>
<script src="ckeditor/ckeditor.js"></script>
            </body>
</html>