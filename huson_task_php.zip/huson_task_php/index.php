<?php 
	header('location:http://localhost/huson_task_php/admin/');
?>